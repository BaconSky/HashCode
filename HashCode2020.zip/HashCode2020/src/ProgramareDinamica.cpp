#include "ProgramareDinamica.h"

ProgramareDinamica::ProgramareDinamica()
{
    //ctor
}

ProgramareDinamica::~ProgramareDinamica()
{
    //dtor
}
