#include "Book.h"

Book::Book() {

}
Book::Book(int id, int score) : id(id), score(score) {

}

Book::~Book()
{
    //dtor
}
