#ifndef PROGRAMAREDINAMICA_H
#define PROGRAMAREDINAMICA_H


class ProgramareDinamica
{
    public:
        ProgramareDinamica();
        virtual ~ProgramareDinamica();

    protected:

    private:
};

#endif // PROGRAMAREDINAMICA_H
