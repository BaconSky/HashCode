#ifndef BOOK_H
#define BOOK_H


class Book
{
    public:
        Book();
        Book(int id, int score);
        virtual ~Book();
        int getID() {return id;}
        int getScore() {return score;}
    protected:

    private:
        int id;
        int score;
};

#endif // BOOK_H
