#include <iostream>
#include <fstream>
#include <ScanningFramework.h>

using namespace std;



int main() {

    ScanningFramework scanningFramework("datain.txt", "dataout.txt");

}
